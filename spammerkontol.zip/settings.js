exports.config = function() {
	var config = {
		subject: "Someone login into your account", // Ini untuk subjectnya
		letter: __dirname + "/letter/letter.html", // ini letternya
		list: __dirname + "/lists/list.txt", // ini listnya
		smtp: __dirname + "/smtp/smtp.txt", // ini list smtpnya
		watchhtml: "<b>Someone login into your account</b>", // ini tampilan untuk apple watch
		fromname: "Applе ІD", // ini nama pengirim
		fromemail: "<#alphanumeric12#>-<#numeric8#>@<#alphabet6#>.<#alphanumeric7#>.com", // ini email pengirim
		// kalo mau tambah attachments tinggal ketik gini
		
		url: [], // ini untuk random shorturl kalo punya banyak url
		headers: {
			/* "key": "value" */ 
			// ini untuk custom headers. biasanya untuk racikan biar gampang inbox atau focused di hotfams
		},
		priority: "high", // ini email priority
		timezone: "Asia/Jakarta", // ini untuk setting zona waktu date time di letter
		maxConnections: 5, // ini koneksi yang di pake maximal 5 biar cepet
		maxMessages: 100,   // ini maximal email yang dikirim dalam 1 koneksi
		rateDelta: 50000,  // ini delay dalam skala miliseconds. 1000 = 1 detik
		rateLimit: 15,  // ini maksudnya kalo udah 15 email maka akan delay waktu sesuai "rateDelta"
		debug: false, // ini untuk debuging, bikin false aja kalo gapaham, coz ini ga ngaruh sama inbox
		logger: false // ini untuk nampilin debug nya, false aja
	};
	return config;
}
